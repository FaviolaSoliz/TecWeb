$(document).ready(function(){

// .remove()
	// Elimina el elemento y sus elementos hijo.
		$('h1,h2').remove();
	// $('#contenedor').remove();
	// $('#contenedor').children('#segunda').remove();

// .empty()
	// Elimina los elementos hijos del elemento seleccionado.

	// $('#contenedor').empty();
});