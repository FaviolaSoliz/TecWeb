 //$(document).ready(function(){

	//alert();

	/*
		Nuestro boton no puede acceder a la funcion efecto
		porque esta protegida por la funcion de la primera linea.
		Si la comentamos ya tendra acceso.
	*/

	function efecto(){

		//$(selector).efecto(velocidad, callback);


		/*$('.caja').show(3000, function(){
		//	alert('Oculto');
	 	});

		//$('.caja').show();*/
		//$('.caja').toggle();
		

		// Fades
		// $('.caja').fadeIn(3000);
		// $('.caja').fadeOut();
		// $('.caja').fadeToggle();

		// Sliding
		//$('.caja').slideDown();
		//$('.caja').slideUp();
		//$('.caja').slideToggle();


	};
 //});
