$(document).ready(function(){

	
	$('.caja').on('click', function(){
		 //$(this).css({background: '#000'});
		$(this).toggleClass('color');
	});
});