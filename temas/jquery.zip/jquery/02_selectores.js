$(document).ready(function(){
	//$('h1').hide();
	// varios elementos
	//$('h1, h2, h3').hide();
	//$('.encabezado').hide();
	//$('#primero').hide();

	//$('.primero a').hide();
	//$('p#primero').hide();

	//$('.primero a').hide();
});